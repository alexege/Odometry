﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Odometry_Pose_Estimator
{
    class Program
    {
        static void Main(string[] args)
        {
            Tricycle robot = new Tricycle(0.1250, 0.1250, 0.964, 0.3673, 35136);
            Console.WriteLine(robot.estimate(1, 0, 35136, 0));

            Tricycle robot2 = new Tricycle(0.2, 0.2, 0.75, 1, 512);
            Console.WriteLine( robot2.estimate(1, 0, 512, 0));

            Tricycle robot3 = new Tricycle(0.2, 0.2, 0.75, 1, 512);
            Console.WriteLine(robot3.estimate(1, Math.PI/2, 512, 0));


            //using (var reader = new StreamReader(@"C:\Users\alexe\Desktop\dataset0.csv"))
            //{
            //    List<string> listA = new List<string>();

            //    while (!reader.EndOfStream)
            //    {
            //        var line = reader.ReadLine();
            //        var values = line.Split(';');

            //        robot.estimate(values[0], values[3], values[1], values[2]);

            //        listA.Add(values[0]);
                    
            //        Console.WriteLine(values[0]);


            //    }
            //}

        }
    }
}
